from distutils.core import setup

setup(name='rbc',
      version='0.1dev',
      description='An object library for advanced design and construction',
      author='Nguyen Ngo',
      author_email='mnguyenngo@gmail.com',
      url='https://github.com/rebuildingcode/rbc',
      packages=['src'],
     )